#include "offsets.h"
#include "xorstr.h"

std::vector<COffset::stOffset> COffset::m_offsets;

void COffset::Initialise()
{
	// 32 bit
	Add(xorstr("RwInitialised"), 0x4849729, eArchType::ARM);
	Add(xorstr("RsGlobal"), 0x4E4723C, eArchType::ARM);
	Add(xorstr("JNILib_step"), 0x3E4911, eArchType::ARM);
	Add(xorstr("TouchEvent"), 0x3E4B19, eArchType::ARM);
	Add(xorstr("CNetGame::ProcessNetwork"), 0x2EB941, eArchType::ARM);
	Add(xorstr("CNetGame::Packet_ConnectionLost"), 0x2EC701, eArchType::ARM);
	
	Add(xorstr("CNetGame::m_pRakClient"), 0x486F30C, eArchType::ARM);
	uintptr_t ng_pRakClient = Get(xorstr("CNetGame::m_pRakClient"));
	Add(xorstr("CNetGame::m_iGameState"), ng_pRakClient + 4, eArchType::ARM);
	Add(xorstr("CNetGame::m_pPlayerPool"), ng_pRakClient + 8, eArchType::ARM);
	Add(xorstr("CNetGame::m_pVehiclePool"), ng_pRakClient + 12, eArchType::ARM);
	Add(xorstr("CNetGame::m_pPickupPool"), ng_pRakClient + 16, eArchType::ARM);
	Add(xorstr("CNetGame::m_pTextLabelPool"), ng_pRakClient + 20, eArchType::ARM);
	Add(xorstr("CNetGame::m_pTextDrawPool"), ng_pRakClient + 24, eArchType::ARM);
	Add(xorstr("CNetGame::m_pGangZonePool"), ng_pRakClient + 28, eArchType::ARM);
	Add(xorstr("CNetGame::m_pActorPool"), ng_pRakClient + 32, eArchType::ARM);
	Add(xorstr("CNetGame::m_pObjectPool"), ng_pRakClient + 36, eArchType::ARM);
	Add(xorstr("CNetGame::m_pChatBubblePool"), ng_pRakClient + 40, eArchType::ARM);
	Add(xorstr("CNetGame::m_pWayPointPool"), ng_pRakClient + 44, eArchType::ARM);
	Add(xorstr("CNetTextDrawPool::SetServerLogo"), 0x3452ED, eArchType::ARM);
	Add(xorstr("CNetVehiclePool::New"), 0x346AC1, eArchType::ARM);
	Add(xorstr("CNetGame::Packet_GUI"), 0x2EC95C + 1, eArchType::ARM);
	
	Add(xorstr("CRemotePlayer::StoreAimSyncData"), 0x33F015, eArchType::ARM);
	Add(xorstr("CRemotePlayer::StoreSyncData"), 0x33F0F5, eArchType::ARM);
	Add(xorstr("CRemotePlayer::StoreInCarSyncData"), 0x340691, eArchType::ARM);
	Add(xorstr("CRemotePlayer::StorePassengerSyncData"), 0x340B8D, eArchType::ARM);
	Add(xorstr("CRemotePlayer::StoreBulletSyncData"), 0x3408A5, eArchType::ARM);
	
	Add(xorstr("RakClient::RegisterAsRemoteProcedureCall"), 0x451FED, eArchType::ARM);
	Add(xorstr("CChat::AddDebugMessage"), 0x38B1B1, eArchType::ARM);

	// 64 bit
	Add(xorstr("RwInitialised"), 0x525ADE0, eArchType::ARM64);
	Add(xorstr("RsGlobal"), 0x53A6BC0, eArchType::ARM64);
	Add(xorstr("CNetGame::ProcessNetwork"), 0x4AB6B4, eArchType::ARM64);
	Add(xorstr("CNetGame::Packet_ConnectionLost"), 0x4AC314, eArchType::ARM64);
	
	Add(xorstr("CNetGame::m_pRakClient"), 0x4C4D5F0, eArchType::ARM64);
	Add(xorstr("CNetGame::m_iGameState"), 0x4C4D5F8, eArchType::ARM64);
	// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
	Add(xorstr("CNetGame::m_pPlayerPool"), 0x4C4D600, eArchType::ARM64);
	Add(xorstr("CNetGame::m_pVehiclePool"), 0x4C4D608, eArchType::ARM64);
	Add(xorstr("CNetGame::m_pObjectPool"), 0x4C4D638, eArchType::ARM64);
	Add(xorstr("CNetObjectPool::New"), 0x526E00, eArchType::ARM64);
	// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
	Add(xorstr("CNetVehiclePool::New"), 0x516C38, eArchType::ARM64);
	
	Add(xorstr("CRemotePlayer::StoreAimSyncData"), 0x50D2C0, eArchType::ARM64);
	Add(xorstr("CRemotePlayer::StoreSyncData"), 0x50D3C0, eArchType::ARM64);
	Add(xorstr("CRemotePlayer::StoreInCarSyncData"), 0x50EDE4, eArchType::ARM64);
	Add(xorstr("CRemotePlayer::StorePassengerSyncData"), 0x50F3FC, eArchType::ARM64);
	Add(xorstr("CRemotePlayer::StoreBulletSyncData"), 0x50F070, eArchType::ARM64);

	Add(xorstr("CChat::AddDebugMessage"), 0x569900, eArchType::ARM64);

	// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
	
	Add(xorstr("CNetGame::Packet_GUI"), 0x4AC674, eArchType::ARM64);
}

void COffset::Add(const char* name, uintptr_t addr, eArchType arch)
{
	stOffset nOffset;
	nOffset.name = name;
	nOffset.addr = addr;
	nOffset.arch = arch;
	m_offsets.push_back(nOffset);
}

uintptr_t COffset::Get(const char* name)
{
	uintptr_t result = 0;
	for(int i = 0; i < m_offsets.size(); i++)
	{
#ifdef __aarch64__
		if(m_offsets[i].arch == eArchType::ARM64)
		{
#endif
#ifdef __arm__
		if(m_offsets[i].arch == eArchType::ARM)
		{
#endif
		if(!strcasecmp(name, m_offsets[i].name.c_str()))
		{
			result = m_offsets[i].addr;
			break;
		}
		}
	}
	return result;
}

// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
// t.me/gordeev_mods 
